package ManagedBeans;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.primefaces.model.chart.PieChartModel;

import Services.PostUserService;

@ManagedBean
@ViewScoped
public class ChartJsView {

	private int n;
	private int ac;

	@EJB
	PostUserService so;

	private PieChartModel pieModel1;
	
	@PostConstruct
	public void init() {
		createPieModels();
	}

	public PieChartModel getPieModel1() {
		return pieModel1;
	}

	private void createPieModels() {
		createPieModel1();
	}
private void createPieModel1() {
		
		int CountAcc = (int) so.Sumlike().intValue();
		System.out.println("like "+CountAcc);
		int countEnAtt = (int) so.SumDisLike().intValue();
		System.out.println("dislike "+countEnAtt);
		int total =(int) so.CountPost().intValue();
		System.out.println("total "+total);
		int pourcentageAcc = (int) (CountAcc * 100) / total;
		int pourcentageEnAtt = (int) (countEnAtt * 100) / total;
		

		//System.out.println("ccccccccc "+pourcentageRef);
		
		pieModel1 = new PieChartModel();
		pieModel1.set("Like "+pourcentageAcc+"%", pourcentageAcc);
		pieModel1.set("Dislike"+pourcentageEnAtt+"%", pourcentageEnAtt);
		
		
		pieModel1.setTitle("Etude sur le nombre de Like et dislike par rapport au nombre total des reaction");
		pieModel1.setLegendPosition("w");
	}
	
}
