package ManagedBeans;


/*import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;*/
import java.util.List;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.servlet.http.HttpServletRequest;


import Services.PostUserService;
import model.Comment;
import model.PostUser;


@ManagedBean(name="PostUserBeans")
@SessionScoped
public class PostUserBeans {
	

//	private static final HttpServletRequest Request = null;
	//private static final javax.servlet.http.HttpServletResponse Response = null;



	@EJB
	PostUserService Ps;

  
 
	String contenu;
	String picture;
 List<PostUser> posts ;
 List<PostUser> mposts ;
 List<Comment> com ;

	int dislike;
	int likee;
	private PostUser stat;
	private PostUser PostUserToUpadate;
	private PostUser PostUserTriMax;
	private PostUser ad;
	private PostUser back;
	
	public List<Comment> getCom() {
	return com;
}
public void setCom(List<Comment> com) {
	this.com = com;
}
	
	public String updatePostUser() {
		Ps.updatePostUser(PostUserToUpadate);
		return "ListPostUser";
			
	}
	public String BackList(PostUser PostUser) {
		setBack(PostUser);
		return "ListPostUser";
	}
	public String Statistique(PostUser PostUser) {
		setStat(PostUser);
		return "stat";
	}
	public PostUser getStat() {
		return stat;
	}
	public void setStat(PostUser stat) {
		this.stat = stat;
	}
	public String PostUserMax(PostUser PostUser) {
		setPostUserTriMax(PostUser);
		return "MaxLike";
	}
	public String addp(PostUser PostUser) {
		setAd(PostUser);
		return "AddPostUser";
	}
	public String editPostUser(PostUser PostUser) {
		setPostUserToUpadate(PostUser);
		return "UpdatePostUser";
	}
	public String removePostUser(PostUser PostUser) {
		Ps.deletePostUser(PostUser);
		return null;
	}
	public Long Calcul() {
		return	Ps.CountPost();
		 
	}
	public String commentaire(PostUser postUser) {
		Ps.Comm(postUser);
		return "AddComment";
	}
	public String like(PostUser postUser) {
		Ps.like(postUser);
		return "ListPostUser";
	}
	public String ddislike(PostUser postUser) {
		Ps.dislike(postUser);
		return "ListPostUser";
	}
	
	
    public String addPostUser()  {
		
		PostUser PostUser = new PostUser();
		
		PostUser.setContenu(contenu);
		PostUser.setPicture(picture);
		sendMail.sendEMail("khadija.abid@esprit.tn", "accepté", "Khadija",
				"Abid",1);
		
		Ps.addPostUser(PostUser);
		return "ListPostUser";
	}
	public void setPosts(List<PostUser> posts) {
		this.posts = posts;
	}
	public void setMposts(List<PostUser> mposts) {
		this.mposts = mposts;
	}
	public int getDislike() {
		return dislike;
	}
	public void setDislike(int dislike) {
		this.dislike = dislike;
	}
	public PostUserService getPs() {
		return Ps;
	}
	public void setPs(PostUserService ps) {
		Ps = ps;
	}
	public String getContenu() {
		return contenu;
	}
	public void setContenu(String contenu) {
		this.contenu = contenu;
	}
	public String getPicture() {
		return picture;
	}
	public void setPicture(String picture) {
		this.picture = picture;
	}
	public int getLikee() {
		return likee;
	}
	public void setLikee(int likee) {
		this.likee = likee;
	}
	public PostUser getPostUserToUpadate() {
		return PostUserToUpadate;
	}
	public void setPostUserToUpadate(PostUser postUserToUpadate) {
		PostUserToUpadate = postUserToUpadate;
	}
	public PostUser getBack() {
		return back;
	}
	public void setBack(PostUser back) {
		this.back = back;
	}
	public PostUser getAd() {
		return ad;
	}
	public void setAd(PostUser ad) {
		this.ad = ad;
	}
	public PostUser getPostUserTriMax() {
		return PostUserTriMax;
	}
	public void setPostUserTriMax(PostUser postUserTriMax) {
		PostUserTriMax = postUserTriMax;
	}
	public List<PostUser> getPosts() {
		posts= Ps.getAllPostUser();
		return posts;
	}
	public List<PostUser> getMposts() {	
		mposts= Ps.getAllMaxLike();
	return mposts;
}
	
	
}
