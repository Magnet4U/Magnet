package ManagedBeans;

import java.io.IOException;
import java.io.Serializable;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Named;

import Services.MessageService;
import model.User;

@Named
@ViewScoped
public class ContactsBean implements Serializable{
	
	private String titre;
	private String image;
	private String contenue ;
	private String nomAuteur;
	//private Date datePublish ;
	private User Contact;
	//private News NewsToUpdate ;
	private Integer idToBeUpdated;
//	private List<News> Newss;
	private List<User> Users;
public String getTitre() {
		return titre;
	}
	public void setTitre(String titre) {
		this.titre = titre;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getContenue() {
		return contenue;
	}
	public void setContenue(String contenue) {
		this.contenue = contenue;
	}
	public String getNomAuteur() {
		return nomAuteur;
	}
	public void setNomAuteur(String nomAuteur) {
		this.nomAuteur = nomAuteur;
	}
	public User getContact() {
		return Contact;
	}
	public void setContact(User contact) {
		Contact = contact;
	}
	public Integer getIdToBeUpdated() {
		return idToBeUpdated;
	}
	public void setIdToBeUpdated(Integer idToBeUpdated) {
		this.idToBeUpdated = idToBeUpdated;
	}
	public List<User> getUsers() {
		return Users;
	}
	public void setUsers(List<User> users) {
		Users = users;
	}
	public MessageService getCma() {
		return cma;
	}
	public void setCma(MessageService cma) {
		this.cma = cma;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
MessageService cma;
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@PostConstruct
	public void init()  {
	 
		Map<String, String> paramMap = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap();
		if (paramMap.get("id") != null) {
			this.setContact(this.cma.getUser(Integer.parseInt(paramMap.get("id"))));
			System.out.println(paramMap.get("id")+"dddddddddd");
		}
	}
	public List<User> getAllUser(){
		 
		Users = cma.getAllUsers();
		return Users ;	
			
	}
	public void goToChat(User user) throws IOException {
		FacesContext.getCurrentInstance().getExternalContext().redirect("Discussion.jsf?id="+user.getIdUser());
	}
	
}
