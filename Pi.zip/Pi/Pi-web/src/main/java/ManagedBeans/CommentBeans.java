package ManagedBeans;

import java.util.List;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import Services.CommentService;
import model.Comment;
import model.PostUser;


@ManagedBean(name="CommentBeans")
@SessionScoped
public class CommentBeans {
@EJB
CommentService Cs;

List<Comment> comm ;
String contenuComment;
private int idpost;
private Comment Back;


public String BackList(Comment Comment) {
	setBack(Comment);
	return "ListPostUser";
}


public Comment getBack() {
	return Back;
}

public void setBack(Comment back) {
	Back = back;
}


private PostUser p=new PostUser();


public int getIdpost() 
{
return idpost;
}

public void setIdpost(int idpost)
{
this.idpost = idpost;
}

public String addComment()  {
	
	Comment Comment = new Comment();
	Comment.setContenuComment(contenuComment);
	p.setIdPostU(idpost);
	Comment.setPostUser(p);
	
	Cs.addComment(Comment);
	return "ListComment";
}
public CommentService getCs() {
	return Cs;
}
public void setCs(CommentService cs) {
	Cs = cs;
}
public List<Comment> getComm() {
	comm=Cs.getAllComment();
	return comm;
}
public void setComm(List<Comment> comm) {
	this.comm = comm;
}
public String getContenuComment() {
	return contenuComment;
}
public void setContenuComment(String contenuComment) {
	this.contenuComment = contenuComment;
}
public String removeComment(Comment Comment) {
	Cs.deleteComment(Comment);
	return null;
}

}
