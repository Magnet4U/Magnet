package ManagedBeans;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.ejb.EJB;
import javax.faces.bean.ManagedProperty;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import model.Message;
import model.User;



/**
 * Servlet implementation class ChatServlet
 */
@WebServlet("/EnvoiMessageServlet")
public class EnvoiMessageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	 @EJB
	 Services.MessageService ms ;
	private SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd MMM yyyy HH:mm");
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	protected void processRequest(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		try (PrintWriter out = response.getWriter()) {
			int idUser = Integer.parseInt(request.getParameter("id_user"));
			User userSender = this.ms.getUser(idUser);

			int idReceiver = Integer.parseInt(request.getParameter("id_receiver"));
			User userReceiver = this.ms.getUser(idReceiver);
            
			String messageContent = request.getParameter("message");
			if(messageContent != null) {
				Message message = new Message();
				message.setBody(messageContent);
				
				message.setSource(userSender);
				message.setDestination(userReceiver);
				this.ms.add(message);
			}
			List<Message> messages = this.ms.getMessages(userSender, userReceiver);

			if (messages != null) {
				for (Message msg : messages) {

					
									
					 
						out.println("<div>" + userSender.getFirstname()
								+ "</div>");
						out.println("<div class='direct-chat-text'>");
						out.println(msg.getBody());
						out.println("</div>");
					 
					 
				}
			}
			 
            
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		processRequest(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		processRequest(request, response);
	}

}
