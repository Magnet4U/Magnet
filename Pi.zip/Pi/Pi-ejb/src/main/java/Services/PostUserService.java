package Services;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import Interfaces.PostUserInterface;
import model.Comment;
import model.PostUser;

@Stateless
@LocalBean
public class PostUserService implements PostUserInterface
{
	@PersistenceContext(unitName="Pi-ejb")
	EntityManager entityManager;

	public Long SumDisLike() {
		TypedQuery<Long> query = entityManager.createQuery("select sum (r.dislike) from PostUser r ",
				Long.class);
		return (Long) query.getSingleResult();
	}

	
	public Long Sumlike() {
		TypedQuery<Long> query = entityManager.createQuery("select sum (r.likee) from PostUser r",
				Long.class);
		return (Long) query.getSingleResult();
	}
	public Long CountPost() {
		TypedQuery<Long> query = entityManager.createQuery("select sum (r.likee+r.dislike) from PostUser r ",
				Long.class);
		return (Long) query.getSingleResult();
	}
	
	
	@Override
	public List<PostUser> getAllPostUser() {
		TypedQuery<PostUser> query = entityManager.createQuery("SELECT f FROM PostUser f ", PostUser.class);
		return query.getResultList();
	}
	@Override
	public void addPostUser(PostUser PostUser) {
		Date date = new Date ();
		PostUser.setDatePublication(date);
		entityManager.persist(PostUser);	
	}
/*	@Override
	public void uploadPostUser(HttpServletRequest request,HttpServletResponse response,PostUser PostUser) throws Exception {
		Date date = new Date ();
		
		FileItemFactory itemfactory = new DiskFileItemFactory();
		ServletFileUpload upload = new ServletFileUpload(itemfactory) ;
		
		List<FileItem> items;
		
			items = upload.parseRequest(request);
			String picture="";
		for(FileItem item:items)
		{
			
			
			//String contentType= item.getContentType();
			File uploadDir=new File("C:\\Users\\Khadija Abid\\Pictures\\uploadfile");
			//File file =File.createTempFile("img", ".png", uploadDir);

			picture = new File(item.getName()).getName();
	        String filePath = uploadDir + File.separator + picture;
	        File file = new File(filePath);
	        
			
			item.write(file);
			
		}
		PostUser.setDatePublication(date);
		PostUser.setPicture(picture);
		entityManager.persist(PostUser);	
	}*/
	
	public void like(PostUser PostUser) {
		
		PostUser.setLikee(+1);
		entityManager.merge(PostUser);	
	}
	
	public void dislike(PostUser PostUser) {
		
		PostUser.setDislike(+1);
		entityManager.merge(PostUser);	
	}
	
public void Comm(PostUser PostUser) {
	List<Comment> comments = new ArrayList<>();		
	PostUser.setComments(comments);
		entityManager.merge(PostUser);	
	}
	@Override
	public void updatePostUser(PostUser PostUser) {
		entityManager.merge(PostUser);
		}

	@Override
	public void deletePostUser(PostUser PostUser) {
		entityManager.remove(entityManager.find(PostUser.class, PostUser.getIdPostU()));
	}
	public List<PostUser> getAllMaxLike()  {
		TypedQuery<PostUser> query = entityManager.createQuery("SELECT f FROM PostUser f ORDER BY f.likee DESC", PostUser.class);
		return query.getResultList();
	}
	
}
