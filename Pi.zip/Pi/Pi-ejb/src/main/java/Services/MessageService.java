package Services;

import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import model.Message;
import model.User;

@Stateless
@LocalBean
public class MessageService {
	@PersistenceContext
    EntityManager em; 
	
	
	public void add(Message m) {
    	em.persist(m);
    }	
	
	public List<Message> getMessages(User sender, User receiver){
		TypedQuery<Message> query;
		query = em.createQuery("select m from Message m "
				+ "where (m.sender.idUser=:idUser and m.receiver.idUser=:idUsers_idUser) "
				+ "or (m.sender.idUser=:idUser and m.receiver.idUser=:idUsers_idUser) "
				+ "order by m.idMessage", Message.class);
		query.setParameter("idUser", sender.getIdUser());
		query.setParameter("idUsers_idUser", receiver.getIdUser());
		
		try {
			return query.getResultList();
		}catch (Exception e) {
			System.err.println(e.getMessage());
		}
		return null;
    }
	public List<User> getAllUsers() {
TypedQuery<User> query;
		
		query=em.createQuery("SELECT e FROM User e",User.class);
		List<User> Users = query.getResultList();
		return Users;
}
    public User getUser(int id) {
    	return em.find(User.class,id);
    }
}
