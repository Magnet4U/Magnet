package Services;

import java.util.Date;
import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import Interfaces.CommentInterface;
import Interfaces.PostUserInterface;
import model.Comment;
import model.PostUser;
import model.User;

@Stateless
@LocalBean
public class CommentService implements CommentInterface
{
	@PersistenceContext(unitName="Pi-ejb")
	EntityManager entityManager;
	
	@Override
	public List<Comment> getAllComment() {
		TypedQuery<Comment> query = entityManager.createQuery("SELECT f FROM Comment f ", Comment.class);
		return query.getResultList();
	}
	@Override
	public void addComment(Comment Comment) {
		Date date = new Date ();
		Comment.setDatePublication(date);
		entityManager.persist(Comment);	
	}
	@Override
	public void updateComment(Comment Comment) {
		entityManager.merge(Comment);
		}

	@Override
	public void deleteComment(Comment Comment) {
		entityManager.remove(entityManager.find(Comment.class, Comment.getIdComment()));
	}
}
