package Interfaces;

import java.util.List;

import javax.ejb.Remote;

import model.Message;
import model.User;

@Remote
public interface MessageInterface {
	void add(Message m);
	List<Message> getMessages(User sender, User receiver);
	List<User> getAllUsers() ;
	User getUser(int id) ;
}
