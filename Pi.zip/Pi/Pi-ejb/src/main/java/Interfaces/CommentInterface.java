package Interfaces;

import java.util.List;

import javax.ejb.Remote;

import model.Comment;

@Remote
public interface CommentInterface {

	List<Comment> getAllComment();

	void addComment(Comment Comment);

	void deleteComment(Comment Comment);

	void updateComment(Comment Comment);

}
