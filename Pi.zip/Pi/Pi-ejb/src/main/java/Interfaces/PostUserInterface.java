package Interfaces;

import java.util.Date;
import java.util.List;

import javax.ejb.Remote;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.PostUser;
@Remote
public interface PostUserInterface {

	//List<PostUser> findAllPostUsers();

	List<PostUser> getAllPostUser();

	void addPostUser(PostUser PostUser);

	void updatePostUser(PostUser PostUser);

	void deletePostUser(PostUser PostUser);
	List<PostUser> getAllMaxLike() ;
	void like(PostUser PostUser);
	void dislike(PostUser PostUser);
	Long CountPost() ;
	Long Sumlike();
	Long SumDisLike();
	

	//void uploadPostUser(HttpServletRequest request,HttpServletResponse response ,PostUser PostUser) throws Exception;

}
