package model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the Likes database table.
 * 
 */
@Entity
@Table(name="Likes")
@NamedQuery(name="Like.findAll", query="SELECT l FROM Like l")
public class Like implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idlike;

	@Column(name="Dislikes")
	private int dislikes;

	private int likes;

	//bi-directional many-to-one association to PostUser
	@ManyToOne
	@JoinColumn(name="idPostUser_idPostU")
	private PostUser postUser;

	//bi-directional many-to-one association to User
	@ManyToOne
	@JoinColumn(name="idUser_idUser")
	private User user;

	public Like() {
	}

	public int getIdlike() {
		return this.idlike;
	}

	public void setIdlike(int idlike) {
		this.idlike = idlike;
	}

	public int getDislikes() {
		return this.dislikes;
	}

	public void setDislikes(int dislikes) {
		this.dislikes = dislikes;
	}

	public int getLikes() {
		return this.likes;
	}

	public void setLikes(int likes) {
		this.likes = likes;
	}

	public PostUser getPostUser() {
		return this.postUser;
	}

	public void setPostUser(PostUser postUser) {
		this.postUser = postUser;
	}

	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

}