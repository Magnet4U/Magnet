package model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;



/**
 * The persistent class for the Comments database table.
 * 
 */
@Entity
@Table(name="Comments")
@NamedQuery(name="Comment.findAll", query="SELECT c FROM Comment c")
public class Comment implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idComment;

	private String contenuComment;

	@Column(name="date_publication")
	private Date datePublication;

	//bi-directional many-to-one association to PostUser
	@ManyToOne
	@JoinColumn(name="idPostUser_idPostU")
	private PostUser postUser;

	//bi-directional many-to-one association to User
	@ManyToOne
	@JoinColumn(name="idUser_idUser")
	private User user;

	public Comment() {
	}

	public int getIdComment() {
		return this.idComment;
	}

	public void setIdComment(int idComment) {
		this.idComment = idComment;
	}

	public String getContenuComment() {
		return this.contenuComment;
	}

	public void setContenuComment(String contenuComment) {
		this.contenuComment = contenuComment;
	}

	public Date getDatePublication() {
		return this.datePublication;
	}

	public void setDatePublication(Date date) {
		this.datePublication = date;
	}

	public PostUser getPostUser() {
		return this.postUser;
	}

	public void setPostUser(PostUser postUser) {
		this.postUser = postUser;
	}

	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}


		
	}
