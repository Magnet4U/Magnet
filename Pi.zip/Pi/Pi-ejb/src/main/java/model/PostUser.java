package model;

import java.io.Serializable;
import javax.persistence.*;

import java.util.Date;
import java.util.List;


/**
 * The persistent class for the PostUsers database table.
 * 
 */
@Entity
@Table(name="PostUsers")
@NamedQuery(name="PostUser.findAll", query="SELECT p FROM PostUser p")
public class PostUser implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idPostU;

	private String contenu;

	@Column(name="date_publication")
	private Date datePublication;

	private int dislike;

	private int likee;

	@Column(name="Picture")
	private String picture;

	//bi-directional many-to-one association to Comment
	@OneToMany(mappedBy="postUser")
	private List<Comment> comments;

	//bi-directional many-to-one association to Like
	@OneToMany(mappedBy="postUser")
	private List<Like> likes;

	//bi-directional many-to-one association to User
	@ManyToOne
	@JoinColumn(name="idUser_idUser")
	private User user;

	public PostUser() {
	}

	public int getIdPostU() {
		return this.idPostU;
	}

	public void setIdPostU(int idPostU) {
		this.idPostU = idPostU;
	}

	public String getContenu() {
		return this.contenu;
	}

	public void setContenu(String contenu) {
		this.contenu = contenu;
	}

	public Date getDatePublication() {
		return this.datePublication;
	}

	public void setDatePublication(Date date) {
		this.datePublication = date;
	}

	public int getDislike() {
		return this.dislike;
	}

	public void setDislike(int dislike) {
		this.dislike = dislike;
	}

	public int getLikee() {
		return this.likee;
	}

	public void setLikee(int likee) {
		this.likee = likee;
	}

	public String getPicture() {
		return this.picture;
	}

	public void setPicture(String picture) {
		this.picture = picture;
	}

	public List<Comment> getComments() {
		return this.comments;
	}

	public void setComments(List<Comment> comments) {
		this.comments = comments;
	}

	public Comment addComment(Comment comment) {
		getComments().add(comment);
		comment.setPostUser(this);

		return comment;
	}

	public Comment removeComment(Comment comment) {
		getComments().remove(comment);
		comment.setPostUser(null);

		return comment;
	}

	public List<Like> getLikes() {
		return this.likes;
	}

	public void setLikes(List<Like> likes) {
		this.likes = likes;
	}

	public Like addLike(Like like) {
		getLikes().add(like);
		like.setPostUser(this);

		return like;
	}

	public Like removeLike(Like like) {
		getLikes().remove(like);
		like.setPostUser(null);

		return like;
	}

	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

}